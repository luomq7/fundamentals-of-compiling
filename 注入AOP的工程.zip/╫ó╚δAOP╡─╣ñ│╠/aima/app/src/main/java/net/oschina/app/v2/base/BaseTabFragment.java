package net.oschina.app.v2.base;

public class BaseTabFragment extends BaseFragment {


}
