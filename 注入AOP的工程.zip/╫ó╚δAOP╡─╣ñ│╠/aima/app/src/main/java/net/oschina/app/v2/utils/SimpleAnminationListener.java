package net.oschina.app.v2.utils;

import android.view.animation.Animation;

/**
 * Created by Aille on 2015/6/28.
 */
public class SimpleAnminationListener implements Animation.AnimationListener {
    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
