package net.oschina.app.v2.activity.user;

import android.support.v4.widget.MySwipeRefreshLayout;

/**
 * Created by Tonlin on 2015/8/21.
 */
public interface SwipeRefreshViewControl {

    public MySwipeRefreshLayout getSwipeRefreshView();
}
