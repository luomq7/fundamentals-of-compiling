package com.lsy.app.help.util;

import android.util.Log;

/**
 * Created by Administrator on 2016/5/6.
 */
public class Util {
    public static void printLog(String log){
        Log.d("日志信息", log);
    }
}

