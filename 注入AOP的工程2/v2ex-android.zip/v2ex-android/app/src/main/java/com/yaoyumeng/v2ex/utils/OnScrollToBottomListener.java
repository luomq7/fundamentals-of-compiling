package com.yaoyumeng.v2ex.utils;

/**
 * Created by yw on 2015/5/23.
 */
public interface OnScrollToBottomListener {
    public void onLoadMore();
}
