package com.example.administrator.searchpicturetool.setting;

import com.jude.beam.bijection.Presenter;

/**
 * Created by wenhuaijun on 2015/11/14 0014.
 */
public class SettingPresenter extends Presenter<SettingActivity> {
}
