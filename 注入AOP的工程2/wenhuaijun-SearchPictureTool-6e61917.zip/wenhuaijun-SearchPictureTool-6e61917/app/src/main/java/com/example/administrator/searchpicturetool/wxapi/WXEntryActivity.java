
package com.example.administrator.searchpicturetool.wxapi;


import com.umeng.socialize.weixin.view.WXCallbackActivity;

public class WXEntryActivity extends WXCallbackActivity {

}
