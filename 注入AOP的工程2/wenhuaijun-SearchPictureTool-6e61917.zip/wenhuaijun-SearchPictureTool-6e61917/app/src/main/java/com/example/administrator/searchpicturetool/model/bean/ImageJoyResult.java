package com.example.administrator.searchpicturetool.model.bean;

@Deprecated
public class ImageJoyResult {
   ImageJoy[] result;

    public ImageJoy[] getResult() {
        return result;
    }

    public void setResult(ImageJoy[] result) {
        this.result = result;
    }
}
