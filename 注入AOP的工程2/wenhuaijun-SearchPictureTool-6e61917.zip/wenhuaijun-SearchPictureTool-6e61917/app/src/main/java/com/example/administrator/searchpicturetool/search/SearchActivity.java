package com.example.administrator.searchpicturetool.search;

import android.view.ViewGroup;

import com.example.administrator.searchpicturetool.base.BaseListActivity;
import com.jude.easyrecyclerview.adapter.BaseViewHolder;

/**
 * Created by WenHuaijun on 2016/10/4 0004.
 */

public class SearchActivity extends BaseListActivity {
    @Override
    protected BaseViewHolder getViewHolder(ViewGroup parent, int viewType) {
        return null;
    }
}
