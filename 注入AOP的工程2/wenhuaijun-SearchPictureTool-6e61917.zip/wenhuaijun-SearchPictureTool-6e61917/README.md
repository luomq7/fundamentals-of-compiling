## 农村淘宝2018届实习内推
>部门简介
农村淘宝cun.taobao.com：是阿里巴巴的三大战略项目之一。为了服务农民，创新农业，让农村变得更美好，阿里巴巴通过农村淘宝项目，推出“千县万村计划”，计划在三至五年内投资100亿元，建立1000个县级服务中心和10万个村级服务站。


![timg.jpg](http://upload-images.jianshu.io/upload_images/685195-ded4ebd3d856280d.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

#### 招聘岗位：
* 前端开发工程师
* 客户端开发工程师
* Java研发工程师
* 测试开发工程师

#### 工作地点
杭州市滨江园区

#### 可以被内推的学生
在校大学生且2018年毕业的应届生
#### 内推的好处
内推成功后，直接跳过笔试环节进入电话面试环节。面试成功后即可直接来实习
#### 内推方式
如需内推请将简历发送到我的邮箱
我的邮箱：huaijun.whj@alibaba-inc.com

# 图片搜索APP(3.4.0版本)

Material Design风格，使用Rxjava，MVP快速开发框架，封装的RecyclerView，retrofit 2.0网络请求库，Fresco图片加载库，图片瀑布流和错位式布局。具有热门推荐、每日一笑、板块分类、一键下载图片、分享图片、收藏图片、设为桌面壁纸、设为锁屏壁纸。

# Screenshot

![1](http://img.wdjimg.com/mms/screenshot/e/22/40616abd669502c43a7c167f4461b22e_320_534.jpeg "")
![2](http://img.wdjimg.com/mms/screenshot/f/5e/c0763134833ab3bdb497f9e1346015ef_320_534.jpeg "")
![3](http://img.wdjimg.com/mms/screenshot/a/69/7b790d6ee7159b3940abf7363865069a_320_534.jpeg "")
![4](http://img.wdjimg.com/mms/screenshot/e/98/8f14df514f7205ce30fe514325bd798e_320_534.jpeg "")
![5](http://img.wdjimg.com/mms/screenshot/f/1d/51c27bc0f0942e506879ae2b22bee1df_320_534.jpeg "")

# 下载地址

豌豆荚市场：http://www.wandoujia.com/apps/com.example.administrator.searchpicturetool

小米应用市场：http://app.mi.com/detail/235067?ref=search



Copyright 2016 wenhuaijun

###该开源项目遵循GPL v3 开源协议。
